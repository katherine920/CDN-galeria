const express = require('express');
const cors = require('cors'); // Importa CORS
const app = express();
const routes = require('./src/routes');
const port = 3001;

// Habilita CORS para todas las rutas
app.use(cors());

routes(app);

app.get('/', (req, res) => res.send('Hello World!'));

app.listen(port, () => console.log(`Example app listening on port ${port}!`));