const CloudFlare = require('../services/cloudflare');

async function onNewImages(path) {
    const cloudFlare = CloudFlare.getInstance();
    return await cloudFlare.uploadImage(path);
}

async function onDeleteImages(imageId) {
    const cloudFlare = CloudFlare.getInstance();
    return await cloudFlare.deleteImage(imageId);
}

async function onListImages() {
    try {
        const cloudflare = CloudFlare.getInstance();
        const response = await cloudflare.client.get('/accounts/513e4a1c22c112b791455d79282b4145/images/v1'); // Account ID actualizado

        if (response.data.success) {
            return response.data.result.images.map(image => ({
                id: image.id,
                filename: image.filename,
                uploaded: image.uploaded,
                smallUrl: image.variants[0], // URL pequeña (250x250)
                largeUrl: image.variants[3] // URL grande (750x750)
            }));
        } else {
            throw new Error("No se pudieron obtener las imágenes");
        }
    } catch (error) {
        console.error("Error al obtener imágenes:", error.message);
        return { success: false, message: error.message };
    }
}

module.exports = {
    onNewImages,
    onDeleteImages,
    onListImages,
};