const FormData = require('form-data');
const fs = require('fs');
const Client = require('./axios');

class CloudFlare extends Client {
    static instance;

    constructor() {
        super();
    }

    static getInstance() {
        if (!CloudFlare.instance) {
            CloudFlare.instance = new CloudFlare();
        }
        return CloudFlare.instance;
    }

    async uploadImage(path) {
        try {
            const formData = new FormData();
            formData.append('file', fs.createReadStream(path)); // Leer como stream

            const response = await this.client.post(
                `/accounts/513e4a1c22c112b791455d79282b4145/images/v1`, // Account ID actualizado
                formData,
                {
                    headers: {
                        ...formData.getHeaders(), // Usar los headers correctos de form-data
                    },
                }
            );

            return response.data;
        } catch (error) {
            console.error("Error al subir imagen:", error.message);
            return { success: false, message: error.message };
        }
    }

    async deleteImage(imageId) {
        try {
            const response = await this.client.delete(
                `/accounts/513e4a1c22c112b791455d79282b4145/images/v1/${imageId}` // Account ID actualizado
            );
            return response.data;
        } catch (error) {
            console.error("Error al eliminar imagen:", error.message);
            return { success: false, message: error.message };
        }
    }
}

module.exports = CloudFlare;