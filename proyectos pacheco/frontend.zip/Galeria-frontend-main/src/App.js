import React, { useState, useEffect } from "react";
import axios from "axios";
import "./App.css";

const ImageUploader = () => {
  const [images, setImages] = useState([]);

  useEffect(() => {
    fetchImages();
  }, []);

  const fetchImages = async () => {
    try {
      const response = await axios.get("http://localhost:3001/images/list");
      setImages(response.data);
    } catch (error) {
      console.error("Error fetching images:", error);
    }
  };

  const handleUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);

    try {
      await axios.post("http://localhost:3001/images/upload", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      alert("Imagen subida exitosamente");
      fetchImages();
    } catch (error) {
      console.error("Error uploading image:", error);
      alert("Error al subir la imagen");
    }
  };

  const triggerFileInput = () => {
    document.getElementById("file-input").click();
  };

  return (
    <div className="container">
      <h2 className="title">CDN de Imágenes</h2>
      <button className="upload-button" onClick={triggerFileInput}>
        Subir Imagen
      </button>
      <input
        id="file-input"
        type="file"
        style={{ display: "none" }}
        onChange={handleUpload}
      />
      <div className="image-grid">
        {images.map((img, index) => {
          return (
            <div key={index} className="image-container">
              <img
                src={img.smallUrl}
                alt="subida"
                onClick={() => window.open(img.largeUrl, "_blank")}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ImageUploader;
